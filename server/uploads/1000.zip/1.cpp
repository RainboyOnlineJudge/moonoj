#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<map>
using namespace std;

int main(){
    int a= max(1,2);
    return 0;
}
