// ==UserScript==
// @name         fress-site 获取
// @namespace    http://tampermonkey.net/
// @require      https://cdn.jsdelivr.net/npm/file-saver@1.3.8/FileSaver.min.js
// @version      0.1
// @description  try to take over the world!
// @author       Rainboy
// @grant        GM_addStyle
// @grant        unsafeWindow
// @match        https://free-ss.site/
// ==/UserScript==

(function() {
  'use strict';
  var ht = '<div class="rainboy">click me</div>'

  GM_addStyle(".rainboy{ text-align:center;\
      background:#444;\
      color:#fff;\
  }")

  $('body').prepend(ht)

  var ssjsons = []
  var ssjsons_raw = []
  var gui_configs = {"configs":[]}
  $('div.rainboy').click(function(){
    $('tr.odd,tr.even').each(function(idx,e){
      if(idx ==0 || idx == 1) return ;//f过滤前两个
      var td = $(this).find('td')
      if($(td[0]).text() == 'No data available in table') return;
      gui_configs.configs.push({
        remarks:$(td[6]).text()+' '+$(td[0]).text()+' idx:'+(idx-1),
        server:$(td[1]).text(),
        server_port:$(td[2]).text(),
        method:$(td[3]).text(),
        password:$(td[4]).text()
      })

    })
    var content = JSON.stringify(gui_configs,null,2)
    var blob = new Blob([content], {type: "text/plain;charset=utf-8"});
    saveAs(blob,'gui_configs.conf')
  });

  // Your code here...
})();
